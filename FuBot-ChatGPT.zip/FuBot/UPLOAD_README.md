# FuBot source review copy

Original project files and current data were not modified or deleted.

This lightweight copy includes source, tests, available text fixtures and reports. It excludes dependencies, Git history, runtime databases/data/uploads, WhatsApp sessions/cache, real .env files, logs, screenshots, build outputs, large files and captured result JSON. Known secret-token patterns were redacted only in this copy. It is not a full operational backup.

Start with backend/evals/targeted-reliability/REPORT.md for the latest rejected repair and rollback findings. Referenced raw runtime results are intentionally omitted.

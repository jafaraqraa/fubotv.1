const { addLog, reportError } = require('./logger');
const {
    retrieveContextAsync,
    getSystemPrompt,
    getLastRetrievalMetadata
} = require('./knowledge');
const { getChatHistoryForAI } = require('../database/repositories/messageRepository');
const {
    validateAnswer: runValidation,
    getLastValidationMetadata
} = require('../rag/intelligence/answerValidator');
const { enabled } = require('../rag/runtime/fallbackPolicy');
const {
    DECISION,
    ARABIC_CLARIFY_MESSAGE,
    clarificationForQuery,
    needsClarification,
    decideEvidence
} = require('../rag/intelligence/evidenceDecisionGate');
const {
    shouldBlockOpenDomain,
    blockOpenDomain,
    validateWithPolicy
} = require('../rag/runtime/fallbackPolicy');
const PromptBuilder = require('./PromptBuilder');
const OpenRouterService = require('./OpenRouterService');
const { MODE, classifyConversationMode } = require('./conversationModeRouter');
const { performance } = require('perf_hooks');
const {
    applyGroundingSafetyBoundary,
    enforcementAssignment
} = require('../rag/security/groundingSafetyBoundary');
const { getConfig } = require('../rag/config/ragConfig');
const crypto = require('crypto');
const ragTraceRepo = require('../database/repositories/ragRequestTraceRepository');

function traceClaims(validation) {
    return (validation?.claims || []).map(claim => ({
        text: claim.propositionText || claim.text || null,
        evidenceIds: claim.evidenceChunkIds || claim.evidenceIds || [],
        verdict: claim.classification || claim.finalClassification || null,
        reason: claim.reason || claim.classificationReason
            || claim.numericResult?.reason
            || (claim.missingEvidence ? 'missing_evidence' : null)
            || (claim.classification ? `validator_${String(claim.classification).toLowerCase()}` : null),
        matchedEvidenceId: claim.matchedEvidenceId
            || claim.evidenceChunkIds?.[0] || claim.evidenceIds?.[0] || null,
        numericVerdict: claim.numericResult?.relation || null,
        temporalVerdict: claim.temporalResult?.relation || claim.temporalVerdict || null,
        negationVerdict: claim.negationResult?.relation || claim.negationVerdict || null
    }));
}

/**
 * High-resolution Timing Profiler for AI response generation pipeline.
 */
class PipelineProfiler {
    constructor() {
        this.stages = {};
        this.subStages = {};
        this.startTime = performance.now();
        this.apiDetails = {};
    }

    startStage(name) {
        this.stages[name] = { start: performance.now() };
    }

    endStage(name) {
        if (this.stages[name]) {
            this.stages[name].end = performance.now();
            this.stages[name].duration = this.stages[name].end - this.stages[name].start;
        }
    }

    recordDuration(name, ms) {
        this.stages[name] = { duration: ms };
    }

    recordSubDuration(parent, name, ms) {
        if (!this.subStages[parent]) {
            this.subStages[parent] = [];
        }
        this.subStages[parent].push({ name, duration: ms });
    }

    setApiDetails(details) {
        this.apiDetails = { ...this.apiDetails, ...details };
    }

    getReport() {
        const total = performance.now() - this.startTime;
        const report = {};
        for (const [name, data] of Object.entries(this.stages)) {
            report[name] = data.duration || 0;
        }
        return {
            stages: report,
            subStages: this.subStages,
            total,
            apiDetails: this.apiDetails
        };
    }
}

/**
 * 1. retrieveContext()
 * Retrieves context asynchronously using the retrieval engine.
 */
async function retrieveContext(userText, profiler = null, retrievalContext = {}) {
    return await retrieveContextAsync(userText, profiler, retrievalContext);
}

/**
 * 2. buildPrompt()
 * Builds the final prompt/messages payload using PromptBuilder.
 */
function buildPrompt(conversationHistory, systemPrompt, context, userText, options = {}) {
    return PromptBuilder.buildMessages({
        systemPrompt,
        conversationHistory,
        knowledgeContext: context,
        userQuestion: userText,
        responseMode: options.responseMode,
        tenantId: options.tenantId,
        evidenceDecision: options.evidenceDecision
    });
}

function inspectEvidenceTenantIntegrity(chunks, requestTenantId) {
    const evidenceTenantIds = [...new Set((chunks || [])
        .map(chunk => chunk?.tenantId || chunk?.payload?.tenantId)
        .filter(Boolean).map(String))];
    const mismatched = evidenceTenantIds.filter(id => id !== String(requestTenantId));
    return { evidenceTenantIds, valid: mismatched.length === 0, mismatched };
}

/**
 * 3. callOpenRouter()
 * Communicates with the configured AI provider to get completions response.
 * Kept exported with identical signature for absolute backward-compatible API contracts.
 */
async function callOpenRouter(messagesPayload, taskName = 'text_generation', options = {}) {
    const { getAIProviderForTask } = require('./aiProviders');
    const provider = getAIProviderForTask(taskName);

    if (!provider) {
        addLog(`⚠️ تنبيه: لم يتم العثور على مزود الخدمة للمهمة [${taskName}].`);
        return null;
    }

    // Check if API key is required and missing (Ollama runs locally and does not need keys)
    if (!provider.apiKey && (provider.constructor.name !== 'OllamaProvider')) {
        addLog(`⚠️ تنبيه: لم يتم العثور على مفتاح API للذكاء الاصطناعي الخاص بـ [${provider.constructor.name}] في ملف .env أو الإعدادات.`);
        return null;
    }

    return await provider.generate(messagesPayload, options);
}

/**
 * 4. validateAnswer()
 * Validates raw LLM response against context if context exists.
 */
function validateAnswer(rawResponse, context, options = {}) {
    return runValidation(rawResponse, context, options);
}

/**
 * Helper to fetch generation statistical details (cost/tokens) from OpenRouter.
 */
async function fetchOpenRouterGenerationDetails(generationId, apiKey) {
    if (!generationId || !apiKey) return null;
    try {
        console.log(`🌐 Querying OpenRouter Generation API for ID: ${generationId}...`);
        const url = `https://openrouter.ai/api/v1/generation?id=${generationId}`;
        const res = await fetch(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${apiKey}`
            }
        });
        if (res.ok) {
            const payload = await res.json();
            return payload.data || null;
        } else {
            console.warn(`⚠️ OpenRouter Generation API returned status: ${res.status}`);
        }
    } catch (err) {
        console.error('⚠️ Failed to fetch OpenRouter generation details:', err.message);
    }
    return null;
}

/**
 * Modern production-grade unified response generation pipeline.
 * Maintain backward compatibility with: getAIResponse(userId, userText)
 * Now expanded with Task-Based Image Understanding routing support!
 */
async function getAIResponse(userId, userText, messageType = 'text', mediaObj = null, routing = {}) {
    const { requireTenantId } = require('../rag/security/tenantContext');
    const tenantId = requireTenantId(routing.tenantId, 'ai-rag-response');
    const pipelineTelemetry = routing.pipelineTelemetry
        && typeof routing.pipelineTelemetry === 'object' ? routing.pipelineTelemetry : {};
    Object.assign(pipelineTelemetry, {
        resolvedTenantId: tenantId, selectedRoute: null, ragInvoked: false,
        retrievalTenantId: null, retrievedEvidenceCount: 0,
        evidenceTenantIds: [], gateDecision: null, generationMode: null
    });
    const startTime = Date.now();
    const profiler = new PipelineProfiler();
    const requestId = routing.requestId || crypto.randomUUID();
    ragTraceRepo.createTrace({
        requestId,
        messageId: routing.messageId || null,
        tenantId,
        conversationId: routing.conversationId || `${routing.channel || 'unknown'}:${userId}`,
        retrievalQuery: userText
    });

    const isImage = messageType === 'image' || (mediaObj && mediaObj.mimeType && mediaObj.mimeType.startsWith('image/'));
    const isAudio = ['audio', 'voice'].includes(messageType)
        || (mediaObj && mediaObj.mimeType && mediaObj.mimeType.startsWith('audio/'));
    const activeTask = isImage ? 'vision' : 'text_generation';

    // Image Input Validation if active task is vision
    if (isImage && mediaObj) {
        const { validateIncomingImage } = require('../messaging/validateImage');
        const validation = validateIncomingImage(mediaObj);
        if (!validation.valid) {
            addLog(`⚠️ فشل التحقق من الصورة: ${validation.error}`);
            return validation.error;
        }
    }

    // Speech-To-Text Transcription Pipeline Integration
    if (isAudio) {
        if (!mediaObj?.localPath) {
            const error = new Error('تعذّر العثور على ملف الرسالة الصوتية.');
            error.code = 'AUDIO_MEDIA_MISSING';
            throw error;
        }
        profiler.startStage('Speech to Text');
        const { getAIProviderForTask } = require('./aiProviders');
        const sttProvider = getAIProviderForTask('speech_to_text');
        const sttModel = sttProvider ? sttProvider.model : 'whisper-1';
        const sttProviderName = sttProvider ? sttProvider.constructor.name.replace('Provider', '').toLowerCase() : 'openai';

        // Calculate file size on disk safely
        let fileSizeStr = '0 B';
        try {
            const fs = require('fs');
            const path = require('path');
            const absolutePath = mediaObj.localPath.startsWith('/') && !mediaObj.localPath.startsWith('/uploads')
                ? mediaObj.localPath
                : path.join(__dirname, '..', '..', 'public', mediaObj.localPath);
            if (fs.existsSync(absolutePath)) {
                const stats = fs.statSync(absolutePath);
                fileSizeStr = `${(stats.size / 1024).toFixed(1)} KB`;
            }
        } catch (e) {}

        console.log(`🎙️ [SPEECH-TO-TEXT ROUTING] Detected content type: [audio], Selected task: [speech_to_text], Selected provider: [${sttProviderName}], Selected model: [${sttModel}], File Size: [${fileSizeStr}]`);
        addLog(`جاري تفريغ الصوت عبر المهمة [speech_to_text] باستخدام [${sttModel}]...`);

        const sttStartTime = Date.now();
        if (!sttProvider || typeof sttProvider.transcribe !== 'function') {
            const error = new Error('مزوّد تحليل الصوت غير مهيأ بشكل صحيح.');
            error.code = 'STT_PROVIDER_UNAVAILABLE';
            throw error;
        }
        const transcribedText = String(await sttProvider.transcribe(mediaObj) || '').trim();
        const sttDuration = Date.now() - sttStartTime;
        profiler.recordDuration('Speech to Text', sttDuration);

        if (!transcribedText) {
            const error = new Error('لم يتمكن موديل الصوت من استخراج نص من التسجيل.');
            error.code = 'EMPTY_AUDIO_TRANSCRIPT';
            throw error;
        }

        console.log(`🎙️ [SPEECH-TO-TEXT RESULT] Completed characters=${transcribedText.length} durationMs=${sttDuration}`);
        addLog(`اكتمل تفريغ الرسالة الصوتية بنجاح (${sttDuration}ms)`);
        profiler.endStage('Speech to Text');

        // Overwrite userText with transcribed text
        userText = transcribedText;

        // Compare raw provider text with final text passed to RAG pipeline (Audit verification 7)
        console.log(`🎙️ [SPEECH-TO-TEXT HANDOFF] task=text_generation characters=${userText.length}`);
    }

    // 1. Fetch system prompt personality, rules, safety
    const systemPrompt = getSystemPrompt();
    const conversationHistory = getChatHistoryForAI(userId, tenantId, routing.channel || null);
    const routingDecision = isImage
        ? { mode: MODE.COMPANY_KNOWLEDGE, intent: 'Vision', reason: 'media_requires_grounding' }
        : classifyConversationMode(userText, {
            inputType: isAudio ? 'transcribed_audio' : 'text'
        });
    const useCompanyKnowledge = routingDecision.mode === MODE.COMPANY_KNOWLEDGE;
    ragTraceRepo.updateTrace(requestId, {
        route: routingDecision.mode,
        intent: routingDecision.intent,
        retrieval_query: isImage ? (mediaObj?.caption || '') : userText
    });
    pipelineTelemetry.selectedRoute = routingDecision.mode;
    pipelineTelemetry.generationMode = useCompanyKnowledge
        ? 'EVIDENCE_EXCLUSIVE' : 'GENERAL_CONVERSATION';
    let upstreamClarificationNeeded = !isImage
        && needsClarification(userText, conversationHistory);
    if (!isImage && enabled('RAG_EVIDENCE_GATE_ENABLED', false)
        && upstreamClarificationNeeded) {
        pipelineTelemetry.gateDecision = DECISION.CLARIFY;
        if (routing.decisionTelemetry && typeof routing.decisionTelemetry === 'object') {
            Object.assign(routing.decisionTelemetry, {
                decision: DECISION.CLARIFY,
                reason: 'missing_conversation_reference',
                consideredChunkIds: [], excludedTenantChunks: 0, durationMs: 0
            });
        }
        return clarificationForQuery(userText);
    }
    console.log(
        `[AI Routing] mode=${routingDecision.mode} intent=${routingDecision.intent} `
        + `reason=${routingDecision.reason} tenant=${tenantId}`
    );

    // 2. Retrieve Context (RAG)
    // For Vision task, let's keep context lookup if there's text/caption, else retrieve general context
    const retrievalText = isImage ? (mediaObj.caption || '') : userText;
    const shouldRetrieveKnowledge = useCompanyKnowledge
        && (!isImage || Boolean(String(retrievalText || '').trim()));
    const retrievalTelemetry = routing.retrievalTelemetry
        && typeof routing.retrievalTelemetry === 'object'
        ? routing.retrievalTelemetry
        : {};
    const context = shouldRetrieveKnowledge
        ? await retrieveContext(retrievalText, profiler, {
            tenantId,
            telemetry: retrievalTelemetry
        })
        : '';
    const retrievedChunks = retrievalTelemetry.profiling?.topChunks || [];
    upstreamClarificationNeeded = upstreamClarificationNeeded || (!isImage
        && needsClarification(userText, conversationHistory, retrievedChunks));
    const tenantIntegrity = inspectEvidenceTenantIntegrity(retrievedChunks, tenantId);
    Object.assign(pipelineTelemetry, {
        ragInvoked: shouldRetrieveKnowledge,
        retrievalTenantId: shouldRetrieveKnowledge ? tenantId : null,
        retrievedEvidenceCount: retrievedChunks.length,
        evidenceTenantIds: tenantIntegrity.evidenceTenantIds
    });
    if (shouldRetrieveKnowledge && !tenantIntegrity.valid) {
        pipelineTelemetry.gateDecision = DECISION.NO_ANSWER;
        pipelineTelemetry.generationMode = 'BLOCKED_TENANT_MISMATCH';
        return blockOpenDomain(tenantId, 'tenant_evidence_mismatch');
    }
    const retrievalMetadata = shouldRetrieveKnowledge
        ? (retrievalTelemetry.metadata || getLastRetrievalMetadata())
        : {
            retrievalMode: 'SKIPPED_GENERAL_CONVERSATION',
            degraded: false,
            cacheHit: false
        };
    const decisionTelemetry = routing.decisionTelemetry
        && typeof routing.decisionTelemetry === 'object' ? routing.decisionTelemetry : {};
    if (!isImage && useCompanyKnowledge && enabled('RAG_EVIDENCE_GATE_ENABLED', false)) {
        const gate = decideEvidence({
            query: userText,
            chunks: retrievalTelemetry.profiling?.topChunks || [],
            history: conversationHistory,
            tenantId
        });
        Object.assign(decisionTelemetry, gate);
        ragTraceRepo.updateTrace(requestId, {
            evidence_gate_decision: gate.decision,
            evidence_gate_reason: gate.reason
        });
        pipelineTelemetry.gateDecision = gate.decision;
        if (gate.decision === DECISION.CLARIFY) return clarificationForQuery(userText);
        if (gate.decision === DECISION.NO_ANSWER
            && shouldBlockOpenDomain({ knowledgeBaseOnly: routing.knowledgeBaseOnly })) {
            return blockOpenDomain(tenantId, gate.reason);
        }
    }
    console.log(
        `[RAG Routing] mode=${routingDecision.mode} invoked=${shouldRetrieveKnowledge} `
        + `contextAvailable=${Boolean(String(context || '').trim())}`
    );
    ragTraceRepo.updateTrace(requestId, {
        retrieved_chunks_json: (retrievalTelemetry.profiling?.retrievedChunks || []).map(item => ({
            id: item.chunkId, score: item.score, source: item.source
        })),
        selected_context_chunk_ids_json: retrievalTelemetry.profiling?.selectedContextChunkIds
            || retrievedChunks.map(item => item.chunkId || item.id || item.payload?.chunkId).filter(Boolean)
    });
    if (!isImage && useCompanyKnowledge
        && !String(context || '').trim()
        && shouldBlockOpenDomain({ knowledgeBaseOnly: routing.knowledgeBaseOnly })) {
        const blockedAnswer = blockOpenDomain(tenantId, 'insufficient_context');
        return validateWithPolicy({
            answer: blockedAnswer,
            context,
            validator: validateAnswer,
            tenantId
        });
    }

    // 3. Fetch clean conversation history (unmodified)
    // 4. Construct messages payload using Prompt Builder
    profiler.startStage('Prompt Builder');
    // If it's an image, PromptBuilder builds the same array, and we then enrich the last user message inside Providers.
    const messagesPayload = buildPrompt(
        conversationHistory,
        systemPrompt,
        context,
        isImage ? (mediaObj.caption || 'صورة مرفقة') : userText,
        {
            responseMode: routingDecision.mode,
            tenantId,
            evidenceDecision: pipelineTelemetry.gateDecision
        }
    );
    profiler.endStage('Prompt Builder');

    // 5. Send payload to AI provider (Routed to the determined task)
    const { getAIProviderForTask } = require('./aiProviders');
    const taskProvider = getAIProviderForTask(activeTask);
    const activeModel = taskProvider ? taskProvider.model : (isImage ? 'gpt-4o-mini' : (process.env.AI_MODEL || process.env.OPENROUTER_MODEL || 'openrouter/free'));
    const activeProviderName = taskProvider ? taskProvider.constructor.name.replace('Provider', '').toLowerCase() : (process.env.AI_PROVIDER || 'openrouter');
    profiler.setApiDetails({ model: activeModel, provider: activeProviderName });

    // Explicit Vision Routing Log
    const routedContentType = isImage ? 'image' : (isAudio ? 'transcribed_audio' : 'text');
    console.log(`🤖 [AI TASK ROUTING] Content type: [${routedContentType}], Selected task: [${activeTask}], Selected provider: [${activeProviderName}], Selected model: [${activeModel}]`);
    addLog(`معالجة رسالة [${isImage ? 'صورة' : (isAudio ? 'صوت' : 'نص')}] عبر المهمة [${activeTask}] باستخدام [${activeModel}]`);

    const apiStart = Date.now();
    console.log(`🤖 AI Provider API Request started at: ${new Date(apiStart).toISOString()}`);

    // Call the specific task provider with options passing media if vision
    let rawResponse = null;
    let trackSuccess = 1;
    let trackErrorMessage = null;

    try {
        rawResponse = await callOpenRouter(messagesPayload, activeTask, { media: isImage ? mediaObj : null });
    } catch (apiErr) {
        trackSuccess = 0;
        trackErrorMessage = apiErr.message;
    }

    const apiEnd = Date.now();
    ragTraceRepo.updateTrace(requestId, { raw_model_output: rawResponse });
    console.log(`🤖 AI Provider API Request completed at: ${new Date(apiEnd).toISOString()}`);

    const apiLatency = apiEnd - apiStart;
    const operationalMetrics = require('../observability/runtimeMetrics');
    operationalMetrics.increment('ai_provider_requests_total', {
        provider: activeProviderName,
        task: activeTask,
        outcome: trackSuccess ? 'success' : 'failure'
    });
    operationalMetrics.observe('ai_provider_duration_milliseconds', apiLatency, {
        provider: activeProviderName,
        task: activeTask
    });
    const providerApiStage = `${activeProviderName.charAt(0).toUpperCase()}${activeProviderName.slice(1)} API`;
    profiler.recordDuration(providerApiStage, apiLatency);
    profiler.setApiDetails({ latency: apiLatency, startedAt: apiStart, completedAt: apiEnd });

    if (!rawResponse && trackSuccess === 1) {
        trackSuccess = 0;
        trackErrorMessage = "Empty or null response from provider.";
    }

    // 6. Validate response
    let validatedResponse = null;
    if (rawResponse && useCompanyKnowledge && !isImage) {
        profiler.startStage('Answer Validation');
        validatedResponse = validateWithPolicy({
            answer: rawResponse,
            context,
            validator: validateAnswer,
            tenantId,
            validationOptions: { question: userText, tenantId }
        });
        if (routing.validationTelemetry && typeof routing.validationTelemetry === 'object') {
            Object.assign(routing.validationTelemetry, getLastValidationMetadata() || {});
        }
        const validationMetadata = getLastValidationMetadata() || {};
        ragTraceRepo.updateTrace(requestId, { claims_json: traceClaims(validationMetadata) });
        profiler.endStage('Answer Validation');

        if (enabled('RAG_GROUNDING_SAFETY_BOUNDARY_ENABLED', true)) {
            profiler.startStage('Grounding Safety Boundary');
            const shadowMode = enabled('RAG_GROUNDING_SAFETY_BOUNDARY_SHADOW', true);
            const conversationId = routing.conversationId || `${routing.channel || 'unknown'}:${userId}`;
            const rollout = enforcementAssignment({
                tenantId,
                conversationId,
                percent: getConfig('RAG_GROUNDING_SAFETY_ENFORCEMENT_PERCENT'),
                shadowMode
            });
            const boundaryResult = applyGroundingSafetyBoundary({
                answer: validatedResponse,
                validatedAnswer: validatedResponse,
                question: userText,
                tenantId,
                route: routingDecision.mode,
                serverEvidence: retrievedChunks,
                validation: getLastValidationMetadata() || {},
                upstreamDecision: upstreamClarificationNeeded ? DECISION.CLARIFY : null,
                shadowMode,
                enforcementActive: rollout.enforced
            });
            validatedResponse = boundaryResult.outputAnswer;
            pipelineTelemetry.groundingSafety = boundaryResult.telemetry;
            if (routing.validationTelemetry && typeof routing.validationTelemetry === 'object') {
                routing.validationTelemetry.groundingSafety = boundaryResult.telemetry;
            }
            console.log('[GroundingSafetyBoundary]', boundaryResult.telemetry);
            const safetyMetrics = require('../observability/runtimeMetrics');
            const metricNames = ['totalBusinessResponses'];
            metricNames.push(rollout.enforced ? 'enforcedResponses' : 'shadowOnlyResponses');
            metricNames.push(boundaryResult.decision === 'ALLOW' ? 'allowedResponses'
                : boundaryResult.decision === 'PARTIAL' ? 'partialResponses' : 'blockedResponses');
            if (boundaryResult.telemetry.fallbackType === 'CLARIFY') metricNames.push('clarifyFallbacks');
            if (boundaryResult.telemetry.fallbackType === 'NO_ANSWER') metricNames.push('noAnswerFallbacks');
            if (boundaryResult.telemetry.processingErrorCount) metricNames.push('boundaryErrors');
            if (boundaryResult.telemetry.tenantMismatchCount
                || boundaryResult.telemetry.missingTenantEvidenceCount) metricNames.push('tenantIntegrityBlocks');
            if (boundaryResult.telemetry.numericBlockCount) metricNames.push('numericBlocks');
            if (boundaryResult.telemetry.temporalBlockCount) metricNames.push('temporalBlocks');
            if (boundaryResult.telemetry.negationBlockCount) metricNames.push('negationBlocks');
            if (boundaryResult.telemetry.nonresponsiveBlockCount) metricNames.push('nonresponsiveBlocks');
            if (boundaryResult.reasons.includes('UPSTREAM_CLARIFY')) metricNames.push('ambiguityClarifications');
            metricNames.forEach(name => safetyMetrics.increment(`grounding_safety_${name}`));
            Object.assign(boundaryResult.telemetry, { rolloutBucket: rollout.bucket, rolloutPercent: rollout.percent });
            ragTraceRepo.updateTrace(requestId, {
                boundary_decision: boundaryResult.telemetry.boundaryDecision,
                boundary_reasons_json: boundaryResult.telemetry.boundaryReasons || [],
                enforcement_active: boundaryResult.telemetry.enforcementActive,
                fallback_source: boundaryResult.telemetry.fallbackType
                    ? `grounding_boundary_${boundaryResult.telemetry.fallbackType}` : null,
                final_response_type: boundaryResult.telemetry.fallbackType || 'ANSWER_CANDIDATE'
            });
            const boundaryClaims = boundaryResult.claimResults || [];
            const claimTrace = traceClaims(getLastValidationMetadata() || {}).map((claim, index) => ({
                ...claim,
                numericVerdict: boundaryClaims[index]?.numericSafety || claim.numericVerdict,
                temporalVerdict: boundaryClaims[index]?.temporalSafety || claim.temporalVerdict,
                negationVerdict: boundaryClaims[index]?.negationSafety || claim.negationVerdict,
                boundaryReasons: boundaryClaims[index]?.reasons || []
            }));
            ragTraceRepo.updateTrace(requestId, { claims_json: claimTrace });
            profiler.endStage('Grounding Safety Boundary');
        }
    } else if (rawResponse) {
        validatedResponse = String(rawResponse).trim();
    }

    // Record AI Usage Logs to database
    try {
        const analyticsRepository = require('../analytics/analytics.repository');
        const analyticsWebSocket = require('../analytics/analytics.websocket');
        const { getLastResponseMetadata } = require('./aiProviders');

        // Extract real telemetry from Provider's global lastResponseMetadata
        const meta = getLastResponseMetadata();

        let inputTokens = meta && meta.usage ? meta.usage.prompt_tokens : null;
        let outputTokens = meta && meta.usage ? meta.usage.completion_tokens : null;
        let totalTokens = meta && meta.usage ? meta.usage.total_tokens : null;
        let finalCost = meta ? meta.cost : null;
        const generationId = meta ? meta.id : null;
        const respModel = meta ? meta.model : activeModel;

        // A rejected provider request (for example HTTP 429/no credits) has no
        // billable completion telemetry. Do not turn prompt-size estimates into
        // fake provider usage or cost when no provider metadata was returned.
        if (!trackSuccess && !meta) {
            inputTokens = 0;
            outputTokens = 0;
            totalTokens = 0;
            finalCost = 0;
        }

        // Fallbacks for token estimates if not provided
        if (inputTokens === null || inputTokens === undefined) {
            inputTokens = Math.ceil(JSON.stringify(messagesPayload).length / 4);
        }
        if (outputTokens === null || outputTokens === undefined) {
            outputTokens = rawResponse ? Math.ceil(rawResponse.length / 4) : 0;
        }
        if (totalTokens === null || totalTokens === undefined) {
            totalTokens = inputTokens + outputTokens;
        }

        // If provider is openrouter and cost is missing, call generation API
        if (activeProviderName.includes('openrouter') && finalCost === null && generationId && taskProvider && taskProvider.apiKey) {
            console.log(`🔄 OpenRouter request missing cost. Triggering Generation ID Fallback for ID: ${generationId}...`);
            const genDetails = await fetchOpenRouterGenerationDetails(generationId, taskProvider.apiKey);
            if (genDetails) {
                if (genDetails.cost !== undefined && genDetails.cost !== null) {
                    finalCost = parseFloat(genDetails.cost);
                }
                if (genDetails.tokens_prompt !== undefined) {
                    inputTokens = genDetails.tokens_prompt;
                }
                if (genDetails.tokens_completion !== undefined) {
                    outputTokens = genDetails.tokens_completion;
                }
                if (genDetails.tokens_prompt !== undefined && genDetails.tokens_completion !== undefined) {
                    totalTokens = genDetails.tokens_prompt + genDetails.tokens_completion;
                }
            }
        }

        // Default cost estimation fallback if cost is still not resolved
        if (finalCost === null || finalCost === undefined) {
            let costPerInput = 0.0;
            let costPerOutput = 0.0;
            const lowerProvider = activeProviderName.toLowerCase();

            if (lowerProvider.includes('openai')) {
                costPerInput = 0.0000015;  // gpt-4o-mini default estimates
                costPerOutput = 0.000002;
            } else if (lowerProvider.includes('gemini')) {
                costPerInput = 0.000000075;
                costPerOutput = 0.0000003;
            } else if (lowerProvider.includes('openrouter')) {
                // Free models or basic fallback
                costPerInput = 0.0000005;
                costPerOutput = 0.0000015;
            }

            finalCost = (inputTokens * costPerInput) + (outputTokens * costPerOutput);
        }

        // Print exactly what was retrieved/estimated from the AI provider
        console.log({
            provider: activeProviderName,
            model: respModel,
            usage: {
                prompt_tokens: inputTokens,
                completion_tokens: outputTokens,
                total_tokens: totalTokens
            },
            cost: finalCost,
            generationId
        });

        console.log('[Usage] Saving through rebuilt clean-architecture Analytics module...');

        const result = analyticsRepository.recordUsage({
            provider: activeProviderName,
            model: respModel,
            task: activeTask,
            tenant_id: tenantId,
            request_time: new Date(apiStart),
            response_time: new Date(apiEnd),
            duration: apiLatency,
            prompt_tokens: inputTokens,
            completion_tokens: outputTokens,
            total_tokens: totalTokens,
            cost: finalCost,
            success: trackSuccess,
            error_message: trackErrorMessage,
            generation_id: generationId,
            apiKey: taskProvider ? taskProvider.apiKey : null
        });

        // Temporary tracking log requested by user
        console.log(`[UsageTracker]
Provider: ${activeProviderName}
Model: ${respModel}
Task: ${activeTask}
Prompt Tokens: ${inputTokens}
Completion Tokens: ${outputTokens}
Total Tokens: ${totalTokens}
Cost: ${finalCost}
Persisted: ${result.success ? 'true' : 'false'}
Provider Success: ${trackSuccess ? 'true' : 'false'}`);

        // Broadcast real-time Socket update to active dashboard clients
        if (result.success && trackSuccess) {
            analyticsWebSocket.broadcastUsageUpdate({
                provider: activeProviderName,
                model: respModel,
                task: activeTask,
                total_tokens: totalTokens
            });
        }
    } catch (trackErr) {
        console.error("⚠️ Failed to write usage telemetry log:", trackErr.message);
    }

    if (!rawResponse) {
        const error = new Error(trackErrorMessage || 'AI provider returned an empty response');
        error.code = 'AI_PROVIDER_FAILED';
        throw error;
    }

    // 7. Format and print timing report
    const report = profiler.getReport();
    const stagesList = [
        { key: 'Speech to Text', label: 'Speech to Text (Transcription)' },
        { key: 'Normalization', label: 'Normalization' },
        { key: 'Intent Detection', label: 'Intent Detection' },
        { key: 'Query Planner', label: 'Query Planner' },
        { key: 'Query Decomposition', label: 'Query Decomposition' },
        { key: 'Conversation Analysis', label: 'Conversation Analysis' },
        { key: 'Synonym Expansion', label: 'Synonym Expansion' },
        { key: 'HyDE', label: 'HyDE' },
        { key: 'Embeddings (Ollama)', label: 'Embeddings (Ollama)' },
        { key: 'Vector Search (Qdrant)', label: 'Vector Search (Qdrant)' },
        { key: 'Keyword Search', label: 'Keyword Search' },
        { key: 'RRF Fusion', label: 'RRF Fusion' },
        { key: 'Cross Encoder', label: 'Cross Encoder' },
        { key: 'Context Optimizer', label: 'Context Optimizer' },
        { key: 'Prompt Builder', label: 'Prompt Builder' },
        { key: providerApiStage, label: providerApiStage },
        { key: 'Answer Validation', label: 'Answer Validation' }
        , { key: 'Grounding Safety Boundary', label: 'Grounding Safety Boundary' }
    ];

    console.log(`\n================ AI PIPELINE TIMINGS ================\n`);
    let fastestName = '';
    let fastestVal = Infinity;
    let slowestName = '';
    let slowestVal = -Infinity;

    stagesList.forEach(stg => {
        const duration = report.stages[stg.key] || 0;
        const durStr = `${duration.toFixed(0)} ms`;
        const dots = '.'.repeat(Math.max(1, 30 - stg.label.length - durStr.length));
        console.log(`${stg.label} ${dots} ${durStr}`);

        // Print sub-stages if any exist for this stage
        const subs = report.subStages[stg.key];
        if (subs && Array.isArray(subs)) {
            subs.forEach(sub => {
                const subDurStr = `${sub.duration.toFixed(1)} ms`;
                const labelStr = `  • ${sub.name}`;
                const subDots = '.'.repeat(Math.max(1, 30 - labelStr.length - subDurStr.length));
                console.log(`${labelStr} ${subDots} ${subDurStr}`);
            });
        }

        if (duration > 0) {
            if (duration < fastestVal) {
                fastestVal = duration;
                fastestName = stg.label;
            }
            if (duration > slowestVal) {
                slowestVal = duration;
                slowestName = stg.label;
            }
        }
    });

    console.log(`\n----------------------------------------------------`);
    const totalDuration = report.total;
    const totalStr = `${totalDuration.toFixed(0)} ms`;
    const totalDots = '.'.repeat(Math.max(1, 30 - 5 - totalStr.length));
    console.log(`TOTAL ${totalDots} ${totalStr}`);
    console.log(`====================================================\n`);

    // OpenRouter Details
    const promptTokensEstimate = Math.ceil(JSON.stringify(messagesPayload).length / 4);
    const completionTokensEstimate = Math.ceil((rawResponse || '').length / 4);

    console.log(`🤖 AI Provider Latency Details:`);
    console.log(`  • Request Started: ${new Date(report.apiDetails.startedAt || startTime).toISOString()}`);
    console.log(`  • Request Completed: ${new Date(report.apiDetails.completedAt || Date.now()).toISOString()}`);
    console.log(`  • Total API Latency: ${(report.apiDetails.latency || 0).toFixed(0)} ms`);
    console.log(`  • Prompt Token Estimate: ~${promptTokensEstimate} tokens`);
    console.log(`  • Completion Token Estimate: ~${completionTokensEstimate} tokens`);
    console.log(`  • Model Used: ${report.apiDetails.model}`);
    console.log(`  • Provider: ${report.apiDetails.provider}`);
    console.log(`  • Retrieval Mode: ${retrievalMetadata.retrievalMode}`);
    console.log(`  • Retrieval Degraded: ${retrievalMetadata.degraded ? 'yes' : 'no'}`);

    // Bottleneck Detection
    if (slowestName) {
        const slowestPercentage = Math.round((slowestVal / totalDuration) * 100);
        console.log(`\n🚨 BOTTLENECK DETECTION:`);
        console.log(`  • Fastest Stage:\n    ${fastestName} (${fastestVal.toFixed(0)} ms)`);
        console.log(`  • Slowest Stage:\n    ${slowestName} (${slowestVal.toFixed(0)} ms)`);
        console.log(`  • Largest Percentage:\n    ${slowestName} (${slowestPercentage}%)`);
    }
    console.log(`====================================================\n`);

    return validatedResponse;
}

module.exports = {
    getChatHistoryForAI,
    getAIResponse,
    retrieveContext,
    buildPrompt,
    callOpenRouter,
    validateAnswer,
    inspectEvidenceTenantIntegrity
};

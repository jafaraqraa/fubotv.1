const ProviderAdapter = require('./ProviderAdapter');

class GeminiAdapter extends ProviderAdapter {
    getCapabilities() {
        return {
            supportsBalance: false,
            supportsUsage: false,
            supportsQuota: false,
            supportsResetDate: false,
            supportsRateLimits: false
        };
    }

    async fetchUsageInfo() {
        const mockResult = this.parseMockKey('gemini');
        if (mockResult) return mockResult;

        return {
            success: true,
            limitsAvailable: false,
            capabilities: this.getCapabilities(),
            balance: null,
            limit: null,
            usage: null,
            remaining: null,
            billingPeriod: null,
            resetDate: null,
            source: {},
            rawResponse: null,
            errorMessage: 'API Key usage information is not available from this provider.'
        };
    }
}

module.exports = GeminiAdapter;
